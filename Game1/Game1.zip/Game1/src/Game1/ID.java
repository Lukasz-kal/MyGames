package Game1;

public enum ID {

    Player(),
    Ball()

}
